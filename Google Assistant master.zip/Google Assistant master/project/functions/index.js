'use strict'

process.env.DEBUG = 'actions-on-google:*';
const Assist = require('actions-on-google').ApiAiApp;
const functions = require('firebase-functions')

exports.assistantcodelab = functions.https.onRequest((request,response)=>
{
const app = new Assist({request:request,response:response});
let actionMap = new Map();
actionMap.set('input.welcome', welcomeIntent);
actionMap.set('input.coldturkey', coldturkeyIntent);
actionMap.set('input.cthow', cthowIntent);
actionMap.set('input.cttipsyes', cttipsyesIntent);
actionMap.set('input.cttipsyescont', cttipsyescontIntent);
actionMap.set('input.NRT', NRTIntent);
actionMap.set('input.howNRT', howNRTIntent);
actionMap.set('input.whereNRT', whereNRTIntent);
actionMap.set('input.priceNRT', priceNRTIntent);
actionMap.set('input.therapy', therapyIntent);
actionMap.set('input.whytherapy', whytherapyIntent);
actionMap.set('input.howtherapy', howtherapyIntent);
actionMap.set('input.sittrigger', sittriggerIntent);
actionMap.set('input.emotrigger', emotriggerIntent);
actionMap.set('input.alt', altIntent);
actionMap.set('input.whylimit', whylimitIntent);
actionMap.set('input.herbal', herbalIntent);
actionMap.set('input.gaba', gabaIntent);
actionMap.set('input.prac', pracIntent);
actionMap.set('input.meditate', meditateIntent);


app.handleRequest(actionMap);

function welcomeIntent(app)
{
	{
        app.ask('Hi i am Doctor Vic, I will be your virtual guide on how to stop smoking. Be reminded quitting smoking is hard and takes considerable willpower along with deep commitment to achieve your goal of being smoke-free. If you have any question please do not hesitate to ask me.');
		
	}
}

function coldturkeyIntent(app)
{
	var n1 = app.getArgument('cold_turkey');
	app.ask('well, cold turkey is when You simply stop smoking and commit yourself to being smoke-free. For some, This is the most common, and seemingly the easiest method for quitting smoking because, it requires no outside aid.');
	
}

function cthowIntent(app)
{
	{
        app.ask('you simply just stop, Honestly, it depends on your willpower. However, you can use nicotine replacement therapy to ease you through the process. would you like to know the tips on how to do cold turkey successfully?');
		
	}
}

function cttipsyesIntent(app)
{
	{
        app.ask('for a start, you can try to take up new activities to replace smoking, particularly something that will occupy your hands or mouth, like knitting or chewing sugarless gum. Besides that, try to avoid situations and people that you associate with smoking. shall i continue?');
		
	}
}

function cttipsyescontIntent(app)
{
	{
        app.ask('you should have a backup strategy in case you find it difficult to go cold turkey. for example, try to consume medicine or go for a smoking therapy.');
		
	}
}

function NRTIntent(app)
{
	var n1 = app.getArgument('NRT');
	app.ask('NRT or Nicotine Replacement Therapy is one of the most successful tools for treating smoking addiction, with a 20% success rate. it usually comes in the form of chewing gums, lozenges and patches. Be reminded that, This strategy requires some financial investment to buy the product.');
	
}

function howNRTIntent(app)
{
	{
        app.ask('By chewing gums, eating lozenges, or wearing patches, you get the nicotine into your bodies crave while gradually lowering the dosage, eventually weaning them off nicotine. In the process, you will move away from addictive behavior and towards healthy activities.');
		
	}
}

function whereNRTIntent(app)
{
	{
        app.ask('you can get NRT from any local drugstore or you can go see a doctor at the nearest clinic and ask to prescribed with NRT.');
		
	}
}

function priceNRTIntent(app)
{
	{
        app.ask('The price of Nicotine Replacement depends on the brand and type. Generally in Malaysia you can get them at the price from 35 ringgit and above at local drugstore.');
		
	}
}

function therapyIntent(app)
{
	var n1 = app.getArgument('therapy');
	app.ask('Another way, to stop smoking is you can go go to counseling or therapy.  you can work with a counselor or therapist to address the underlying emotional issues that drive your smoking. This will help you figure out the emotional or situational triggers that push you to smoke.');
	
}

function whytherapyIntent(app)
{
	{
        app.ask('A mental health professional can help you develop a long-term plan for addressing your addiction. For some, smoking addiction is very hard to overcome therefor any help is might come in handy. If you do not want to see a therapy you can always ask help from your friends or loved one');
		
	}
}

function howtherapyIntent(app)
{
	{
        app.ask('There a lot of ways to ask for a therapist. For instance, you can call a university psychiatry or psychology department and ask recommendations. Besides that, you can also call a large clinic; ask the receptionist for recommendations.');
		
	}
}

function sittriggerIntent(app)
{
	{
        app.ask('situational trigger in smoking simply means a situation that might pressure you to have smoke, for example when hanging out with friends who smoke or being offer to smoke a cigarette for free.');
		
	}
}

function emotriggerIntent(app)
{
	{
        app.ask('emotional trigger in smoking simply means a situation where your emotion affect your smoke cravings. For Example, if you feel stressed or pressured you might think to catch a break and have a smoke.');
		
	}
}

function altIntent(app)
{
	var n1 = app.getArgument('alternative');
	app.ask('There are a number of different alternative practices that can help you quit smoking. These range from herbal supplements to practices like meditation. However be reminded that, there is limited scientific evidence supporting this statement.');
	
}

function whylimitIntent(app)
{
	{
        app.ask('This is because some of these alternative way is not recognized by world health association, and does not guarantee success. Therefore, if you choose this way, please consult your personal doctor.');
		
	}
}

function herbalIntent(app)
{
	{
        app.ask('Herbal supplement such as GABA can be used to help quit smoking. Another alternatives is by ingesting Vitamin C candies and lozenges to which few smokers believe can help curb their cravings.');
		
	}
}

function gabaIntent(app)
{
	var n1 = app.getArgument('GABA');
	app.ask('GABA is a supplement specifically made to curb nicotine dependency. research  found that increasing GABA may decrease the pleasurable effects a smoker gets from nicotine.For more information visit www.naturalhealthyconcepts.com to learn more about the product.');
	
}

function pracIntent(app)
{
	var n1 = app.getArgument('practices');
	app.ask('besides meditating you can also practice other things such yoga or chewing gum, It depends really. The important point is to distract your mind from thinking about lighting a cigarette.');
	
}

function meditateIntent(app)
{
	var n1 = app.getArgument('meditate');
	app.ask('Meditation can be a useful practice to help distract your mind for the desire to smoke. to learn more about meditation to quit smoking, go google it!');
	
}


});


